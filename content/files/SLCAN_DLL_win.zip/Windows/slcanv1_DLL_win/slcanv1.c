﻿
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <windows.h>
#include <setupapi.h>
#include <devguid.h>
#include <regstr.h>
#include <initguid.h>
#include <process.h>
#include <inttypes.h>
#include "slcan.h"
#include "slcanv1.h"
//#include "slcanv1_extern.h"
#pragma comment(lib, "setupapi.lib")

#define VID "VID_16D0"
#define PID "PID_117F"
#define SERIAL_PORT fullPort
#define ERR_FLAG 5
#define RX_FLAG 1
#define TX_FLAG 1


#define CAN_10K         0U              /**< bit-rate:   10 kbit/s */
#define CAN_20K         1U              /**< bit-rate:   20 kbit/s */
#define CAN_50K         2U              /**< bit-rate:   50 kbit/s */
#define CAN_100K        3U              /**< bit-rate:  100 kbit/s */
#define CAN_125K        4U              /**< bit-rate:  120 kbit/s */
#define CAN_250K        5U              /**< bit-rate:  250 kbit/s */
#define CAN_500K        6U              /**< bit-rate:  500 kbit/s */
#define CAN_800K        7U              /**< bit-rate:  800 kbit/s */
#define CAN_1000K       8U              /**< bit-rate: 1000 kbit/s */
#define CAN_1M          CAN_1000K


static char fullPort[20];
int rc = 0;
int slcan_started = 0;
int running = 1;
int mutexForDataReceiveFunction = 0;
HANDLE rxThread;


//typedef struct slcanv1Frame {
//    uint8_t channel;
//    uint32_t id;
//    uint8_t dlc;
//    uint8_t data[8];
//    uint8_t ext;
//    uint8_t fd;
//    uint8_t loopback;
//    uint8_t rtr;
//} slcanv1Frame;


void(__cdecl* c_rx_cb)(slcanv1Frame* f) = NULL;

unsigned __stdcall rxmessage_thread(void* arg) {
    slcanv1hnd hnd = (slcanv1hnd)arg;
    slcanv1Frame f;
    slcan_message_t slcan_mess_read;
    while (running) {
        // Continuously read message from serial port
        if (slcan_read_message(hnd, &slcan_mess_read,0) == 0) {
            if (c_rx_cb) {
                // Call the global callback
                f.channel = 0;
                f.ext = 0;
                f.fd = 0;
                if (slcan_mess_read.error > 0) {
                    f.loopback =  ERR_FLAG ;
                    f.id = 0xAAA1;
                }
                else {

                    f.loopback = RX_FLAG;
                    f.rtr = 0;
                    f.dlc = slcan_mess_read.can_dlc;
                    f.id = slcan_mess_read.can_id;
                    if (f.id & CAN_XTD_FRAME)
                    {
                        f.id = f.id & CAN_XTD_MASK;
                        f.ext = 1;

                    }
                    memcpy(f.data, slcan_mess_read.data, sizeof(slcan_mess_read.data));
                }
                while (mutexForDataReceiveFunction) {

                }
                mutexForDataReceiveFunction = 1;
                c_rx_cb(&f);
                mutexForDataReceiveFunction = 0;
            }
        }
    }

    return 0;
}

__declspec(dllexport) slcanv1hnd slcanv1_init() {

	return slcan_create(500U);
}

__declspec(dllexport) int32_t slcanv1_deinit(slcanv1hnd hnd) {
    rc = slcan_destroy(hnd);
    return rc;
}

__declspec(dllexport) int32_t slcanv1_open(slcanv1hnd hnd) {
    rc = slcan_connect(hnd, SERIAL_PORT, NULL);
    if (rc < 0) {
        rc = slcan_disconnect(hnd);
        return rc;
    }
    rc = slcan_set_ack(hnd, true);
    if (rc < 0) {
        rc = slcan_disconnect(hnd);
        return rc;
    }
    rc = slcan_version_number(hnd, NULL, NULL);
    if (rc < 0) {
        rc = slcan_set_ack(hnd, false);
        if (rc < 0) {
            rc = slcan_disconnect(hnd);
            return rc;
        }
    }
    return 0;
}

__declspec(dllexport) int32_t slcanv1_close(slcanv1hnd hnd) {
    rc = slcan_disconnect(hnd);
    if (rc < 0) {
        return rc;
    }
    return 0;
}

__declspec(dllexport) int32_t slcanv1_set_rx_callback(slcanv1hnd hnd, void(__cdecl* callback)(slcanv1Frame* f)) {
    c_rx_cb = callback;
    running = 1;
    // Start the thread if not already running
    if (rxThread == NULL) {
        rxThread = (HANDLE)_beginthreadex(NULL, 0, rxmessage_thread, hnd, 0, NULL);
        if (rxThread == NULL) {
            return -1; // Thread creation failed
        }
    }
    return 0;
}

__declspec(dllexport) int32_t slcanv1_start(slcanv1hnd hnd) {
    rc = slcan_open_channel(hnd);
    if (rc < 0) {
        return rc;
    }
    slcan_started = 1;
    return 0;
}
__declspec(dllexport) int32_t slcanv1_stop(slcanv1hnd hnd) {
    running = 0;
    if (rxThread) {
        WaitForSingleObject(rxThread, 1000);
        CloseHandle(rxThread);
        rxThread = NULL;
    }
    rc = slcan_disconnect(hnd);
    if (rc < 0) {
        
        return 0;
    }
    slcan_started = 0; 
    return 1;
}

__declspec(dllexport) int32_t slcanv1_transmit(slcanv1hnd hnd, const struct slcanv1Frame f) {
    slcan_message_t slcan_mess;
    if (slcan_started == 0)
    {
        return -1;
    }

    slcan_mess.can_dlc = f.dlc;
    if (f.ext)
    {
        slcan_mess.can_id = f.id | 0x80000000U;
    }
    else
    {
        slcan_mess.can_id = f.id;
    }
    memcpy(slcan_mess.data, f.data, sizeof(f.data));
    slcan_mess.__pad = 0;
    slcan_mess.__res1 = 0;
    slcan_mess.__res2 = 0;
    rc = slcan_write_message(hnd, &slcan_mess, 5);
    if (rc < 0)
        return rc;

    return 1;
}

__declspec(dllexport) int32_t slcanv1_set_bitrate(slcanv1hnd hnd, uint8_t channel, uint32_t bitrate) {
    uint8_t bitrate_value = CAN_500K;
    switch(bitrate) {
    case 10000:
        bitrate_value = CAN_10K;
        break;
    case 20000:
        bitrate_value = CAN_20K;
        break;
    case 50000:
        bitrate_value = CAN_50K;
        break;
    case 100000:
        bitrate_value = CAN_100K;
        break;
    case 125000:
        bitrate_value = CAN_125K;
        break;
    case 250000:
        bitrate_value = CAN_250K;
        break;
    case 500000:
        bitrate_value = CAN_500K;
        break;
    case 800000:
        bitrate_value = CAN_800K;
        break;
    case 1000000:
        bitrate_value = CAN_1000K;
        break;
    
    }

    rc = slcan_setup_bitrate(hnd, bitrate_value);
    if (rc < 0) {
        return 0;
    }
    return 1;
	
}

__declspec(dllexport) void ConvertWcharToChar(char* wstr, char* str, int size) {
    // Convert the Wide String to Normal String
    int j = 0;
    for (int i = 0; i <125; i++)
    {
        // Convert only the lower byte (discard the NULL byte)
        
            str[j++] = (char)wstr[2*i+1] ;
            
        
    }
    str[j] = '\0';
    //WideCharToMultiByte(CP_ACP, 0, wstr, -1, str, 125, NULL, NULL);
}

__declspec(dllexport) int32_t slcanv1_get_channel(slcanv1hnd hnd, char * serialPortOut) {
    char serialPort[20];
    char serialPortToOpen[20];
    
    HDEVINFO deviceInfoSet = SetupDiGetClassDevs(&GUID_DEVCLASS_PORTS, NULL, NULL, DIGCF_PRESENT);
    if (deviceInfoSet == INVALID_HANDLE_VALUE) {
        return 0;
    }

    SP_DEVINFO_DATA deviceInfoData;
    deviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);

    for (DWORD i = 0; SetupDiEnumDeviceInfo(deviceInfoSet, i, &deviceInfoData); i++) {
        char hardwareID[256];
        char hardwareID2[256];
        if (SetupDiGetDeviceRegistryProperty(deviceInfoSet, &deviceInfoData, SPDRP_HARDWAREID, NULL,
            (BYTE*)hardwareID2, sizeof(hardwareID2), NULL)) {
            //ConvertWcharToChar(hardwareID2, hardwareID, 256);
            WideCharToMultiByte(CP_ACP, 0, hardwareID2, -1, hardwareID, 256, NULL, NULL);


            //for (int i = 0; i < 256; i++) {
            //    printf("%c", hardwareID[i]);
            //}
            //printf("\n");

            if (strstr(hardwareID, VID) && strstr(hardwareID, PID)) {

                HKEY hKey = SetupDiOpenDevRegKey(deviceInfoSet, &deviceInfoData, DICS_FLAG_GLOBAL, 0, DIREG_DEV, KEY_READ);
                if (hKey) {
                    DWORD type;
                    DWORD size = 20;
                    if (RegQueryValueExA(hKey, "PortName", NULL, &type, (LPBYTE)serialPort, &size) == ERROR_SUCCESS) {
                        snprintf(serialPortToOpen, sizeof(serialPortToOpen), "\\\\.\\%s", serialPort);
                        HANDLE hCom = CreateFileA(serialPortToOpen, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
                        if (hCom != INVALID_HANDLE_VALUE) {
                            CloseHandle(hCom);
                            RegCloseKey(hKey);

                            SetupDiDestroyDeviceInfoList(deviceInfoSet);

                            //printf("\\\\.\\%s", serialPort);
                            snprintf(fullPort, sizeof(fullPort), "\\\\.\\%s", serialPort);
                            snprintf(serialPortOut, 30, "SLCAN (%s)", serialPort);
                            return 1;
                        }
                    }
                    RegCloseKey(hKey);
                }
            }
        }
    }

    SetupDiDestroyDeviceInfoList(deviceInfoSet);




	return 0;
}


__declspec(dllexport) int slcanv1_readMessage(slcanv1hnd hnd, slcanv1Frame* f) {
    slcan_message_t slcan_mess_read;

    if (slcan_read_message(hnd, &slcan_mess_read, 0) == 0) {
        f->channel = 0;
        f->ext = 0;
        f->fd = 0;

        if (slcan_mess_read.error > 0) {
            f->loopback = ERR_FLAG;
            f->id = 0xAAA1;
        }
        else {
            f->loopback = RX_FLAG;
            f->rtr = 0;
            f->dlc = slcan_mess_read.can_dlc;
            f->id = slcan_mess_read.can_id;
            if (f->id & CAN_XTD_FRAME)
            {
                f->id = f->id & CAN_XTD_MASK;
                f->ext = 1;

            }
            memcpy(f->data, slcan_mess_read.data, sizeof(slcan_mess_read.data));
        }
        return 0;
    }
    else {
        return -1;
    }
}
