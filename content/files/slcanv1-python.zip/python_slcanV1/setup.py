from setuptools import setup, find_packages

setup(
    name='slcanv1',
    version='0.1.2',
    packages=find_packages(),
    include_package_data=True,
    package_data={'slcanv1': ['*.dll']},
    author='Your Name',
    author_email='you@example.com',
    description='Python wrapper for slcanv1.dll',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    zip_safe=False,
)
