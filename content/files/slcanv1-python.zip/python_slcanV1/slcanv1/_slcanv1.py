import ctypes
import os
import sys

def is_64bit_python():
    return sys.maxsize > 2**32

if is_64bit_python():
    _dll_path = os.path.join(os.path.dirname(__file__), "slcanv1_DLL_win_64bit.dll")
    print("Python is running in 64-bit mode.")
else:
    _dll_path = os.path.join(os.path.dirname(__file__), "slcanv1_DLL_win_32bit.dll")
    print("Python is running in 32-bit mode.")


_dll = ctypes.CDLL(_dll_path)

slcanv1hnd = ctypes.c_void_p

class Frame(ctypes.Structure):
    _fields_ = [
        ("channel", ctypes.c_uint8),
        ("id", ctypes.c_uint32),
        ("dlc", ctypes.c_uint8),
        ("data", ctypes.c_uint8 * 8),
        ("ext", ctypes.c_uint8),
        ("fd", ctypes.c_uint8),
        ("loopback", ctypes.c_uint8),
        ("rtr", ctypes.c_uint8),
        ("error", ctypes.c_uint8),
    ]

_dll.slcanv1_init.restype = slcanv1hnd
_dll.slcanv1_deinit.restype = ctypes.c_int32
_dll.slcanv1_open.restype = ctypes.c_int32
_dll.slcanv1_close.restype = ctypes.c_int32
_dll.slcanv1_get_channel.restype = ctypes.c_int32
_dll.slcanv1_set_bitrate.restype = ctypes.c_int32
_dll.slcanv1_start.restype = ctypes.c_int32
_dll.slcanv1_stop.restype = ctypes.c_int32
_dll.slcanv1_transmit.restype = ctypes.c_int32
_dll.slcanv1_readMessage.restype = ctypes.c_int
_dll.slcanv1_readMessage_timeout.restype = ctypes.c_int
_dll.slcanv1_readMessage_WithMask.restype = ctypes.c_int

_dll.slcanv1_get_channel.argtypes = [slcanv1hnd, ctypes.c_char_p]
_dll.slcanv1_open.argtypes = [slcanv1hnd]
_dll.slcanv1_close.argtypes = [slcanv1hnd]
_dll.slcanv1_deinit.argtypes = [slcanv1hnd]
_dll.slcanv1_set_bitrate.argtypes = [slcanv1hnd, ctypes.c_uint8, ctypes.c_uint32]
_dll.slcanv1_start.argtypes = [slcanv1hnd]
_dll.slcanv1_stop.argtypes = [slcanv1hnd]
_dll.slcanv1_transmit.argtypes = [slcanv1hnd, Frame]
_dll.slcanv1_readMessage.argtypes = [slcanv1hnd, ctypes.POINTER(Frame)]
_dll.slcanv1_readMessage_timeout.argtypes = [slcanv1hnd, ctypes.POINTER(Frame),ctypes.c_uint8]
_dll.slcanv1_readMessage_WithMask.argtypes = [slcanv1hnd, ctypes.POINTER(Frame),ctypes.c_uint32,ctypes.c_uint32,ctypes.c_uint8]

class SlcanV1:
    def __init__(self):
        self._hnd = _dll.slcanv1_init()
        if not self._hnd:
            raise RuntimeError("Failed to init slcanv1")

    def get_channel(self):
        port_out = ctypes.create_string_buffer(256)
        ok = _dll.slcanv1_get_channel(self._hnd, port_out)
        print(port_out.value)
        if ok:
            return port_out.value.decode()
        else:
            return None

    def open(self):
        rc = _dll.slcanv1_open(self._hnd)
        if rc != 0:
            raise RuntimeError(f"Open failed: {rc}")

    def close(self):
        _dll.slcanv1_close(self._hnd)

    def deinit(self):
        _dll.slcanv1_deinit(self._hnd)

    def set_bitrate(self, bitrate):
        rc = _dll.slcanv1_set_bitrate(self._hnd, 0, bitrate)
        if rc != 1:
            raise RuntimeError(f"Set bitrate failed: {rc}")

    def start(self):
        rc = _dll.slcanv1_start(self._hnd)
        if rc != 0:
            raise RuntimeError(f"Start failed: {rc}")

    def stop(self):
        _dll.slcanv1_stop(self._hnd)

    def transmit(self, can_id, data: bytes, ext=False):
        f = Frame()
        f.channel = 0
        f.id = can_id
        f.dlc = len(data)
        f.ext = 1 if ext else 0
        for i in range(len(data)):
            f.data[i] = data[i]
        rc = _dll.slcanv1_transmit(self._hnd, f)
        return rc

    def read(self):
        f = Frame()
        rc = _dll.slcanv1_readMessage(self._hnd, ctypes.byref(f))
        if rc == 0:
            return {
                "id": f.id,
                "dlc": f.dlc,
                "data HEX": bytes(f.data[:f.dlc]).hex(),
                "ext": bool(f.ext),
                "ERROR": f.error != 0,
                "rtr": f.rtr
            }
        else:
            return None
    
    def read_timeout(self,timeout):
        f = Frame()
        rc = _dll.slcanv1_readMessage_timeout(self._hnd, ctypes.byref(f),timeout)
        if rc == 0:
            return {
                "id": f.id,
                "dlc": f.dlc,
                "data HEX": bytes(f.data[:f.dlc]).hex(),
                "ext": bool(f.ext),
                "ERROR": f.error != 0,
                "rtr": f.rtr
            }
        else:
            return None
        
    def read_withMask(self,filter_id,mask_id,timeout):
        f = Frame()
        rc = _dll.slcanv1_readMessage_WithMask(self._hnd, ctypes.byref(f),filter_id,mask_id,timeout)
        if rc == 0:
            return {
                "id": f.id,
                "dlc": f.dlc,
                "data HEX": bytes(f.data[:f.dlc]).hex(),
                "ext": bool(f.ext),
                "ERROR": f.error != 0,
                "rtr": f.rtr
            }
        else:
            return None