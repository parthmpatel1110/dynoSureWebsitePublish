import subprocess
import sys
import ctypes
import os
import sys

subprocess.check_call([sys.executable, "-m", "pip", "install", " python_slcanV1.zip"])

from slcanv1 import SlcanV1

slcan = SlcanV1()
print("Channel:", slcan.get_channel())
slcan.open()
slcan.set_bitrate(500000)
slcan.start()

# slcan.transmit(0x123, b'\x11\x22\x33\x44')
i = 0

while(i < 10):
    frame = slcan.read_timeout(timeout=1000)
    if frame != None:
        print("Received:", frame)
        print("id = ",frame.id)
        print("dlc =",frame.dlc)
        print("Data =",frame.data[:])
        print("erorr =",frame.error)
        i = i + 1
        print("message count=",i)
        frame.id  = frame.id + 1
        print(slcan.transmit_Frame(frame) ) # 1 = transmit successfull -1 = transmit failed

    else:
        print("NO frame")


# i = 0
# while(i < 10):
#     frame = slcan.read_withMask(filter_id=0x55, mask_id= 0xF0, timeout=100)
#     i = i + 1
#     if frame != None:
#         print("Received:", frame)
        
#         # slcan.transmit(0x123456, b'\x11\x22\x33\x44\x55\x66\x77\x88',ext=1)
#         # slcan.transmit(0x123, b'\x11\x22\x33\x44\x55\x66\x77\x88',ext=0)
#     else:
#         print("NO frame for", i)


# slcan.stop()
# slcan.close()
# slcan.deinit()
