using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

namespace Slcanv2Interop
{
    // ===========================================================================
    //  Data Structures
    // ===========================================================================

    /// <summary>
    /// Extended CAN / CAN FD frame structure (64-byte payload).
    /// Matches slcanv2PacketFD in slcanv2.h.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct Slcanv2PacketFD
    {
        public byte channel;
        public uint id;
        public byte dlc;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
        public byte[] data;

        public byte ext;           // 1 = 29-bit extended CAN ID, 0 = 11-bit standard ID
        public byte fd;            // 1 = CAN FD frame, 0 = Classic CAN 2.0 frame
        public byte brs;           // 1 = Bit Rate Switching enabled
        public byte esi;           // 1 = Error State Indicator
        public byte rtr;           // 1 = Remote Transmission Request
        public byte msg_type;      // 1 = RX frame, 2 = Tx Echo
        public byte error;         // 1 = Bus Error event
        public byte bus_status;    // Bus status error code
        public byte error_level;   // Error level code
        public long timestamp;     // Monotonic timestamp in microseconds

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string timestamp_formated;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string error_msg;
    }

    /// <summary>
    /// Candlelight USB device enumeration entry.
    /// Matches slcanv2DeviceInfo in slcanv2.h.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct Slcanv2DeviceInfo
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string displayName;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string serialNo;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 512)]
        public string devicePath;

        public int channel;        // One-based channel number
    }

    /// <summary>
    /// Candlelight USB device capabilities.
    /// Matches slcanv2DevCapability in slcanv2.h.
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct Slcanv2DevCapability
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string vendor;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string product;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string serial;

        public byte supportsFD;    // 1 = CAN FD supported, 0 = Classic CAN only
        public uint fclk_can;      // CAN clock frequency (Hz)
    }

    // ===========================================================================
    //  P/Invoke Wrapper Class
    // ===========================================================================

    public static class Slcanv2
    {
        public const string DllName = "slcanv2.dll";
        public const string DllName32 = "slcanv2_32bit.dll";
        public const string DllName64 = "slcanv2_64bit.dll";

        private static string? _customDllPath;
        private static IntPtr _loadedHandle = IntPtr.Zero;
        private static string? _loadedDllPath;
        private static readonly object _lock = new object();

        /// <summary>
        /// Gets whether the current running process is 64-bit.
        /// </summary>
        public static bool Is64BitProcess => Environment.Is64BitProcess;

        /// <summary>
        /// Gets the target DLL file name based on process architecture (slcanv2_64bit.dll or slcanv2_32bit.dll).
        /// </summary>
        public static string DefaultDllName => Is64BitProcess ? DllName64 : DllName32;

        /// <summary>
        /// Gets or sets an explicit path or filename for the native DLL, overriding automatic discovery.
        /// Set to null to restore default architecture-based resolution.
        /// </summary>
        public static string? CustomDllPath
        {
            get => _customDllPath;
            set
            {
                lock (_lock)
                {
                    _customDllPath = value;
                    _loadedHandle = IntPtr.Zero;
                    _loadedDllPath = null;
                }
            }
        }

        /// <summary>
        /// Gets the full path or name of the native DLL that was successfully resolved and loaded.
        /// </summary>
        public static string? LoadedDllPath => _loadedDllPath;

        /// <summary>
        /// Gets the native module handle of the loaded DLL, or IntPtr.Zero if not yet loaded.
        /// </summary>
        public static IntPtr LoadedLibraryHandle => _loadedHandle;

        static Slcanv2()
        {
            TryRegisterDllImportResolver();
        }

        private static void TryRegisterDllImportResolver()
        {
            try
            {
                NativeLibrary.SetDllImportResolver(typeof(Slcanv2).Assembly, ResolveDllImport);
            }
            catch (InvalidOperationException)
            {
                // Resolver already registered for this assembly
            }
            catch (Exception)
            {
                // Fallback for environments without NativeLibrary support
            }
        }

        private static IntPtr ResolveDllImport(string libraryName, Assembly assembly, DllImportSearchPath? searchPath)
        {
            if (libraryName == DllName ||
                libraryName == "slcanv2" ||
                libraryName == DllName32 ||
                libraryName == DllName64 ||
                string.Equals(libraryName, "slcanv2.dll", StringComparison.OrdinalIgnoreCase))
            {
                return LoadNativeLibrary();
            }

            return IntPtr.Zero;
        }

        /// <summary>
        /// Explicitly initializes/loads the native DLL with an optional custom path.
        /// </summary>
        /// <param name="customPath">Optional custom path to the 32-bit or 64-bit DLL file.</param>
        /// <returns>Native module handle to the loaded DLL.</returns>
        public static IntPtr Initialize(string? customPath = null)
        {
            if (!string.IsNullOrEmpty(customPath))
            {
                CustomDllPath = customPath;
            }
            return LoadNativeLibrary();
        }

        /// <summary>
        /// Loads the native DLL according to architecture (32-bit vs 64-bit) and configured search paths.
        /// </summary>
        /// <returns>IntPtr handle to the loaded DLL module.</returns>
        public static IntPtr LoadNativeLibrary()
        {
            lock (_lock)
            {
                if (_loadedHandle != IntPtr.Zero)
                {
                    return _loadedHandle;
                }

                string targetFileName = DefaultDllName;

                // 1. Check custom path if set
                string? custom = _customDllPath;
                if (!string.IsNullOrEmpty(custom))
                {
                    if (TryLoadLibraryPath(custom!, out IntPtr customHnd))
                    {
                        _loadedHandle = customHnd;
                        _loadedDllPath = custom;
                        return _loadedHandle;
                    }
                }

                // 2. Search candidate locations for architecture-specific DLL (slcanv2_64bit.dll / slcanv2_32bit.dll)
                var searchPaths = GetSearchPaths(targetFileName);
                foreach (string candidate in searchPaths)
                {
                    if (TryLoadLibraryPath(candidate, out IntPtr hnd))
                    {
                        _loadedHandle = hnd;
                        _loadedDllPath = candidate;
                        return _loadedHandle;
                    }
                }

                // 3. Fallback: search candidate locations for generic slcanv2.dll
                if (!string.Equals(targetFileName, DllName, StringComparison.OrdinalIgnoreCase))
                {
                    var fallbackPaths = GetSearchPaths(DllName);
                    foreach (string candidate in fallbackPaths)
                    {
                        if (TryLoadLibraryPath(candidate, out IntPtr hnd))
                        {
                            _loadedHandle = hnd;
                            _loadedDllPath = candidate;
                            return _loadedHandle;
                        }
                    }
                }

                // 4. Try standard OS resolution using NativeLibrary
                try
                {
                    if (NativeLibrary.TryLoad(targetFileName, typeof(Slcanv2).Assembly, null, out IntPtr nativeHnd) && nativeHnd != IntPtr.Zero)
                    {
                        _loadedHandle = nativeHnd;
                        _loadedDllPath = targetFileName;
                        return _loadedHandle;
                    }
                }
                catch { }

                // 5. Win32 LoadLibrary fallback
                IntPtr win32Hnd = Win32LoadLibrary(targetFileName);
                if (win32Hnd != IntPtr.Zero)
                {
                    _loadedHandle = win32Hnd;
                    _loadedDllPath = targetFileName;
                    return _loadedHandle;
                }

                return IntPtr.Zero;
            }
        }

        private static string[] GetSearchPaths(string fileName)
        {
            var list = new List<string>();

            // AppDomain BaseDirectory (where executable resides)
            string? appBase = AppDomain.CurrentDomain.BaseDirectory;
            if (!string.IsNullOrEmpty(appBase))
            {
                list.Add(Path.Combine(appBase, fileName));
                list.Add(Path.Combine(appBase, Is64BitProcess ? "x64" : "x86", fileName));
                list.Add(Path.Combine(appBase, "runtimes", Is64BitProcess ? "win-x64" : "win-x86", "native", fileName));
                list.Add(Path.Combine(appBase, "slcanv2_lib", fileName));
                try
                {
                    string parent3 = Path.GetFullPath(Path.Combine(appBase, "..", "..", ".."));
                    list.Add(Path.Combine(parent3, fileName));
                    list.Add(Path.Combine(parent3, "slcanv2_lib", fileName));
                }
                catch { }
            }

            // Current working directory
            string cwd = Directory.GetCurrentDirectory();
            if (!string.IsNullOrEmpty(cwd))
            {
                list.Add(Path.Combine(cwd, fileName));
                list.Add(Path.Combine(cwd, Is64BitProcess ? "x64" : "x86", fileName));
                list.Add(Path.Combine(cwd, "slcanv2_lib", fileName));
            }

            // Assembly location directory
            try
            {
                string? asmLoc = typeof(Slcanv2).Assembly.Location;
                if (!string.IsNullOrEmpty(asmLoc))
                {
                    string? asmDir = Path.GetDirectoryName(asmLoc);
                    if (!string.IsNullOrEmpty(asmDir) && !asmDir.Equals(appBase, StringComparison.OrdinalIgnoreCase))
                    {
                        list.Add(Path.Combine(asmDir, fileName));
                        list.Add(Path.Combine(asmDir, "slcanv2_lib", fileName));
                    }
                }
            }
            catch { }

            return list.ToArray();
        }

        private static bool TryLoadLibraryPath(string path, out IntPtr handle)
        {
            handle = IntPtr.Zero;
            if (string.IsNullOrEmpty(path))
                return false;

            try
            {
                if (File.Exists(path))
                {
                    if (NativeLibrary.TryLoad(path, out handle) && handle != IntPtr.Zero)
                    {
                        return true;
                    }

                    handle = Win32LoadLibrary(path);
                    if (handle != IntPtr.Zero)
                    {
                        return true;
                    }
                }
            }
            catch
            {
                // Continue searching
            }

            return false;
        }

        [DllImport("kernel32.dll", EntryPoint = "LoadLibraryW", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr Win32LoadLibrary(string lpLibFileName);

        // -----------------------------------------------------------------------
        //  Device Start Flags (for slcanv2_start_with_flags)
        // -----------------------------------------------------------------------
        public const uint SLCANV2_FLAG_NORMAL          = 0x00000000;
        public const uint SLCANV2_FLAG_LISTEN_ONLY     = 0x00000001;
        public const uint SLCANV2_FLAG_LOOPBACK        = 0x00000002;
        public const uint SLCANV2_FLAG_TRIPLE_SAMPLE   = 0x00000004;
        public const uint SLCANV2_FLAG_ONE_SHOT        = 0x00000008;
        public const uint SLCANV2_FLAG_TIMESTAMP       = 0x00000010; // Enable MCU timestamps
        public const uint SLCANV2_FLAG_FD              = 0x00000100; // CAN FD mode
        public const uint SLCANV2_FLAG_DISABLE_TX_ECHO = 0x00008000; // Disable Tx echo

        // -----------------------------------------------------------------------
        //  Error Codes
        // -----------------------------------------------------------------------
        public const int ERROR_TIMEOUT           = 1460;
        public const int ERROR_INVALID_DEVICE    = 57010;
        public const int ERROR_INVALID_FIRMWARE  = 57011;
        public const int ERROR_CODE_IN_FEEDBACK  = 57012;
        public const int ERROR_RX_FIFO_OVERFLOW  = 57013;
        public const int ERROR_CORRUPT_IN_DATA   = 57014;
        public const int ERROR_UPDATE_FIRMWARE   = 57015;
        public const int ERROR_TOO_MANY_ERRORS   = 57016;

        // -----------------------------------------------------------------------
        //  Timestamp Modes
        // -----------------------------------------------------------------------
        public const int SLCANV2_TIMESTAMP_NONE    = 0;
        public const int SLCANV2_TIMESTAMP_MCU     = 1;
        public const int SLCANV2_TIMESTAMP_WINDOWS = 2;

        // =======================================================================
        //  Device Enumeration
        // =======================================================================

        /// <summary>
        /// Enumerates attached Candlelight USB CAN devices.
        /// </summary>
        /// <param name="devicesOut">Array to receive device information.</param>
        /// <param name="maxDevices">Maximum number of devices to return.</param>
        /// <returns>Number of devices found, or negative error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_enum_devices(
            [In, Out] Slcanv2DeviceInfo[] devicesOut,
            int maxDevices);

        // =======================================================================
        //  Open / Close
        // =======================================================================

        /// <summary>
        /// Opens a Candlelight USB device by its devicePath (obtained from slcanv2_enum_devices).
        /// </summary>
        /// <param name="devicePath">Device path string.</param>
        /// <returns>Handle to the open device, or IntPtr.Zero on failure.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        public static extern IntPtr slcanv2_open(string devicePath);

        /// <summary>
        /// Closes the device and frees the handle and background threads.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <returns>1 on success, -1 on error.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_close(IntPtr hnd);

        // =======================================================================
        //  Bitrate Configuration
        // =======================================================================

        /// <summary>
        /// Configures bit timing parameters for Nominal (Classic CAN) or Data (CAN FD) bitrates.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="isFD">0 = Nominal / Classic CAN timing, 1 = CAN FD Data timing.</param>
        /// <param name="brp">Baud Rate Prescaler.</param>
        /// <param name="seg1">Time segment 1 (Prop_Seg + Phase_Seg1).</param>
        /// <param name="seg2">Time segment 2 (Phase_Seg2).</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_set_bitrate_advanced(
            IntPtr hnd,
            byte isFD,
            int brp,
            int seg1,
            int seg2);

        // =======================================================================
        //  CAN ID Filtering
        // =======================================================================

        /// <summary>
        /// Adds a CAN ID acceptance mask filter (hardware filter, up to 8 filters).
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="is29bit">0 = 11-bit standard ID, 1 = 29-bit extended ID.</param>
        /// <param name="filter_id">CAN ID pattern to match.</param>
        /// <param name="mask">Bitmask (1 = must match filter_id bit, 0 = don't care).</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_add_mask_filter(
            IntPtr hnd,
            byte is29bit,
            uint filter_id,
            uint mask);

        // =======================================================================
        //  Start / Stop
        // =======================================================================

        /// <summary>
        /// Starts the CAN interface with device operating flags (SLCANV2_FLAG_*).
        /// Also starts the background receive thread.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="flags">Bitwise combination of SLCANV2_FLAG_* constants.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_start_with_flags(
            IntPtr hnd,
            uint flags);

        // =======================================================================
        //  Send / Transmit
        // =======================================================================

        /// <summary>
        /// Sends a single CAN or CAN FD packet with a timeout.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="packet">Reference to the packet to transmit.</param>
        /// <param name="timeout_ms">Timeout in milliseconds.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_send_packet(
            IntPtr hnd,
            ref Slcanv2PacketFD packet,
            ulong timeout_ms);

        /// <summary>
        /// Transmits a batch of CAN / CAN FD packets.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="packets">Array of packets to transmit.</param>
        /// <param name="count">Number of packets in array.</param>
        /// <param name="sentCountOut">Receives number of packets actually sent.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_send_packet_batch(
            IntPtr hnd,
            [In] Slcanv2PacketFD[] packets,
            int count,
            out int sentCountOut);

        // =======================================================================
        //  Receive (Polling & Callback)
        // =======================================================================

        /// <summary>
        /// Receives a single packet from the internal queue (synchronous polling).
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="packet">Receives the packet data.</param>
        /// <param name="timeout_ms">Timeout in milliseconds.</param>
        /// <returns>1 = packet received, 0 / ERROR_TIMEOUT = timeout, -2 = bus error, negative = error.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_receive_packet(
            IntPtr hnd,
            out Slcanv2PacketFD packet,
            uint timeout_ms);

        /// <summary>
        /// RX Callback delegate definition for asynchronous reception.
        /// </summary>
        /// <param name="frame">Received CAN/CAN-FD frame reference.</param>
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void RxCallback(ref Slcanv2PacketFD frame);

        /// <summary>
        /// Registers a callback for receiving packets asynchronously from the background thread.
        /// Pass null to unregister and revert to queue-based polling (slcanv2_receive_packet).
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="callback">Callback delegate or null.</param>
        /// <returns>0 on success, -1 on error.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_set_rx_callback(
            IntPtr hnd,
            RxCallback? callback);

        // =======================================================================
        //  Device Info & Details
        // =======================================================================

        /// <summary>
        /// Retrieves hardware capabilities and device info (vendor, product, serial, fclk).
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="capOut">Receives device capability structure.</param>
        /// <returns>0 on success, -1 on error.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_get_device_info(
            IntPtr hnd,
            out Slcanv2DevCapability capOut);

        /// <summary>
        /// Retrieves detailed device description string from firmware.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="detailsOut">StringBuilder buffer to receive string.</param>
        /// <param name="maxLen">Size of buffer in characters.</param>
        /// <returns>0 on success, -1 on error.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        public static extern int slcanv2_get_details(
            IntPtr hnd,
            StringBuilder detailsOut,
            int maxLen);

        // =======================================================================
        //  LED / Identification
        // =======================================================================

        /// <summary>
        /// Controls device LED identification blinking.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="blink">1 = start blinking, 0 = stop blinking.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_identify(
            IntPtr hnd,
            byte blink);

        // =======================================================================
        //  Bus Load Reporting
        // =======================================================================

        /// <summary>
        /// Enables or disables periodic bus load reporting from firmware.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="interval">0 = disable, 1-255 = interval in 100 ms increments.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_enable_busload_report(
            IntPtr hnd,
            byte interval);

        // =======================================================================
        //  DFU / Boot Pin Control
        // =======================================================================

        /// <summary>
        /// Puts the device into USB DFU (Device Firmware Upgrade) mode.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_enter_dfu_mode(IntPtr hnd);

        /// <summary>
        /// Disables the hardware boot pin on supported hardware.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_disable_boot_pin(IntPtr hnd);

        /// <summary>
        /// Queries whether the boot pin is enabled.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="enabledOut">Receives 1 if enabled, 0 if disabled.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_is_boot_pin_enabled(
            IntPtr hnd,
            out byte enabledOut);

        // =======================================================================
        //  Timestamps
        // =======================================================================

        /// <summary>
        /// Retrieves current high-precision host timestamp in microseconds.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <returns>Timestamp in microseconds.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern long slcanv2_get_timestamp(IntPtr hnd);

        /// <summary>
        /// Sets timestamp mode for packet reception.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="mode">SLCANV2_TIMESTAMP_NONE (0), SLCANV2_TIMESTAMP_MCU (1), or SLCANV2_TIMESTAMP_WINDOWS (2).</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl)]
        public static extern int slcanv2_set_timestamp_mode(
            IntPtr hnd,
            int mode);

        // =======================================================================
        //  Error Formatting
        // =======================================================================

        /// <summary>
        /// Formats an error code into a human-readable text message.
        /// </summary>
        /// <param name="hnd">Device handle.</param>
        /// <param name="errorCode">Error code to format.</param>
        /// <param name="msgOut">StringBuilder buffer to receive formatted error message.</param>
        /// <param name="maxLen">Size of buffer in characters.</param>
        /// <returns>0 on success, or error code.</returns>
        [DllImport(DllName, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        public static extern int slcanv2_format_error(
            IntPtr hnd,
            int errorCode,
            StringBuilder msgOut,
            int maxLen);
    }
}
