using System;
using System.Text;
using System.Threading;
using Slcanv2Interop;
using static Slcanv2Interop.Slcanv2;

class Program
{
    // -------- RX Callback Handler (for asynchronous reception) --------
    private static void RxCallbackHandler(ref Slcanv2PacketFD frame)
    {
        if (frame.error == 1)
        {
            Console.WriteLine($"[CALLBACK ERROR] Bus Status: {frame.bus_status}, Level: {frame.error_level}, Msg: {frame.error_msg}");
            return;
        }

        PrintPacket("CALLBACK RX", ref frame);
    }

    // Helper method to display a received CAN/CAN-FD frame
    private static void PrintPacket(string prefix, ref Slcanv2PacketFD frame)
    {
        string frameType = frame.fd == 1 ? "CAN-FD" : "CAN 2.0";
        string idType = frame.ext == 1 ? "EXT" : "STD";
        string echoStr = frame.msg_type == 2 ? " [Tx Echo]" : "";
        string brsStr = frame.brs == 1 ? " [BRS]" : "";

        Console.Write($"[{prefix}] [{frameType}|{idType}]{echoStr}{brsStr} ID=0x{frame.id:X} DLC={frame.dlc} Data: ");

        int len = Math.Min((int)frame.dlc, 64);
        for (int i = 0; i < len; i++)
        {
            Console.Write($"{frame.data[i]:X2} ");
        }

        Console.WriteLine($"| TS: {frame.timestamp_formated} ({frame.timestamp} µs)");
    }

    // Keep reference to prevent GC from collecting the callback delegate
    private static RxCallback? _rxCallback;

    static void Main()
    {
        Console.WriteLine("=================================================");
        Console.WriteLine("       SLCANv2 Candlelight USB CAN / CAN FD      ");
        Console.WriteLine("=================================================");
        Console.WriteLine($"Runtime: {(Is64BitProcess ? "64-bit" : "32-bit")} process");
        Console.WriteLine($"Target DLL: {DefaultDllName}");

        // -------------------------------------------------------------
        // 1. Enumerate Candlelight USB Devices
        // -------------------------------------------------------------
        Console.WriteLine("\n[1] Enumerating devices...");
        var devices = new Slcanv2DeviceInfo[10];
        int count = slcanv2_enum_devices(devices, 10);
        if (count <= 0)
        {
            Console.WriteLine("No Candlelight USB devices found.");
            Console.WriteLine("Please connect a Candlelight / CANable 2.5 device and try again.");
            return;
        }

        Console.WriteLine($"Found {count} device(s):");
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine($"  [{i + 1}] {devices[i].displayName} (Serial: {devices[i].serialNo}, Channel: {devices[i].channel})");
            Console.WriteLine($"      Path: {devices[i].devicePath}");
        }

        // -------------------------------------------------------------
        // 2. Open First Device
        // -------------------------------------------------------------
        Console.WriteLine($"\n[2] Opening device: {devices[0].displayName}...");
        IntPtr handle = slcanv2_open(devices[0].devicePath);
        if (handle == IntPtr.Zero)
        {
            Console.WriteLine("Failed to open device!");
            return;
        }

        Console.WriteLine($"Device opened successfully! Handle: 0x{handle.ToInt64():X}");
        Console.WriteLine($"Loaded native DLL: {LoadedDllPath ?? DefaultDllName}");

        try
        {
            // ---------------------------------------------------------
            // 3. Query Device Info & Capabilities
            // ---------------------------------------------------------
            if (slcanv2_get_device_info(handle, out Slcanv2DevCapability cap) == 0)
            {
                Console.WriteLine($"\n[3] Device Capabilities:");
                Console.WriteLine($"    Vendor:       {cap.vendor}");
                Console.WriteLine($"    Product:      {cap.product}");
                Console.WriteLine($"    Serial:       {cap.serial}");
                Console.WriteLine($"    Supports FD:  {(cap.supportsFD == 1 ? "Yes" : "No")}");
                Console.WriteLine($"    CAN Clock:    {cap.fclk_can:N0} Hz");
            }

            var detailsSb = new StringBuilder(512);
            if (slcanv2_get_details(handle, detailsSb, detailsSb.Capacity) == 0)
            {
                Console.WriteLine($"\n[Firmware Details]:\n{detailsSb}");
            }

            // ---------------------------------------------------------
            // 4. Configure Bitrate
            //    500 kbps Nominal: BRP=2, Seg1=119, Seg2=40 (for 160MHz CAN Clock)
            // ---------------------------------------------------------
            Console.WriteLine("\n[4] Configuring bitrate (500 kbps Nominal)...");
            int brRes = slcanv2_set_bitrate_advanced(handle, 0, 2, 119, 40);
            Console.WriteLine($"    Set bitrate result: {brRes}");

            // ---------------------------------------------------------
            // 5. Start CAN Interface
            //    Flags: Normal mode + Disable Tx Echo + MCU Timestamps
            // ---------------------------------------------------------
            Console.WriteLine("\n[5] Starting CAN interface...");
            uint flags = SLCANV2_FLAG_NORMAL | SLCANV2_FLAG_DISABLE_TX_ECHO | SLCANV2_FLAG_TIMESTAMP;
            int startRes = slcanv2_start_with_flags(handle, flags);
            if (startRes != 0)
            {
                Console.WriteLine($"Failed to start CAN interface! Error code: {startRes}");
                return;
            }
            Console.WriteLine("    CAN interface started successfully!");

            Thread.Sleep(200);

            // ---------------------------------------------------------
            // 6. Transmit Sample CAN Frames
            // ---------------------------------------------------------
            Console.WriteLine("\n[6] Transmitting sample CAN frames...");
            for (int i = 1; i <= 3; i++)
            {
                var tx = new Slcanv2PacketFD
                {
                    channel = 0,
                    id = (uint)(0x100 + i),
                    dlc = 8,
                    data = new byte[64],
                    ext = 0,    // 0 = 11-bit standard ID
                    fd = 0,     // 0 = Classic CAN 2.0
                    rtr = 0
                };

                for (int b = 0; b < 8; b++)
                {
                    tx.data[b] = (byte)((i << 4) | b);
                }

                int sendRes = slcanv2_send_packet(handle, ref tx, 1000);
                if (sendRes == 0)
                {
                    Console.WriteLine($"    TX Frame {i}: ID=0x{tx.id:X3} DLC={tx.dlc} sent OK");
                }
                else
                {
                    Console.WriteLine($"    TX Frame {i}: Failed with error code: {sendRes}");
                }

                Thread.Sleep(200);
            }

            // ---------------------------------------------------------
            // 7. Synchronous Polling with slcanv2_receive_packet
            // ---------------------------------------------------------
            Console.WriteLine("\n[7] ===================================================");
            Console.WriteLine("    Synchronous Reception using slcanv2_receive_packet  ");
            Console.WriteLine("    ===================================================");
            Console.WriteLine("    Listening for incoming frames for up to 3 seconds...");

            // Ensure callback is disabled for synchronous polling
            slcanv2_set_rx_callback(handle, null);

            var rxPacket = new Slcanv2PacketFD();
            int receivedCount = 0;
            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            // Poll for packets for up to 3 seconds
            while (stopwatch.ElapsedMilliseconds < 3000)
            {
                // slcanv2_receive_packet:
                //   Returns 1  = packet received
                //   Returns 0  = timeout (no packet received in timeout window)
                //   Returns -2 = bus error event
                //   Returns negative = error code
                int res = slcanv2_receive_packet(handle, out rxPacket, 500);

                if (res == 1)
                {
                    receivedCount++;
                    PrintPacket($"POLL RX #{receivedCount}", ref rxPacket);
                }
                else if (res == 0 || res == ERROR_TIMEOUT || res == ERROR_CODE_IN_FEEDBACK)
                {
                    Console.WriteLine("    [POLL] No packet received in this interval (timeout).");
                }
                else if (res == -2)
                {
                    Console.WriteLine($"    [POLL ERROR] Bus Error: {rxPacket.error_msg} (Bus Status: {rxPacket.bus_status}, Level: {rxPacket.error_level})");
                }
                else
                {
                    Console.WriteLine($"    [POLL ERROR] slcanv2_receive_packet returned error code: {res}");
                    break;
                }
            }

            Console.WriteLine($"    Polling complete. Total frames received via polling: {receivedCount}");

            // ---------------------------------------------------------
            // 8. Demonstrate Asynchronous Callback (slcanv2_set_rx_callback)
            // ---------------------------------------------------------
            Console.WriteLine("\n[8] Registering asynchronous RX callback for 2 seconds...");
            _rxCallback = new RxCallback(RxCallbackHandler);
            slcanv2_set_rx_callback(handle, _rxCallback);

            Thread.Sleep(2000);

            // Unregister callback
            slcanv2_set_rx_callback(handle, null);
            _rxCallback = null;
            Console.WriteLine("    Asynchronous RX callback unregistered.");
        }
        finally
        {
            // ---------------------------------------------------------
            // 9. Close Device & Cleanup
            // ---------------------------------------------------------
            Console.WriteLine("\n[9] Closing device...");
            slcanv2_close(handle);
            Console.WriteLine("    Device closed. Done.");
        }
    }
}
