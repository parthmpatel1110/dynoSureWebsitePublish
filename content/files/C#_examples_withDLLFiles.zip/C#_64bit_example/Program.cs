﻿using System;
using Slcanv1CPP;  // Reference your managed C++ DLL

namespace SlcanTestApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Create managed wrapper object
                var device = new Slcanv1();

                Console.WriteLine("Device at {0}", device.GetChannel());

                if (device.Open() != 0)
                {
                    Console.WriteLine("Failed to open device");
                    return;
                }
                Console.WriteLine("Device opened successfully");

                if (device.SetBitrate(0, 500000) != 0)
                {
                    Console.WriteLine("Failed to set bitrate.");
                    return;
                }
                Console.WriteLine("Device bitrate set");

                if (device.Start() != 0)
                {
                    Console.WriteLine("Failed to start.");
                    return;
                }
                Console.WriteLine("Device started.");

                // Prepare a CAN frame to transmit
                var txFrame = new Slcanv1Frame
                {
                    channel = 0,
                    id = 0x100,
                    dlc = 8,
                    data = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 },
                    ext = 0,
                    fd = 0,
                    loopback = 0,
                    rtr = 0,
                    error = 0
                };

                // Transmit the frame
                for (int i = 0; i < 10; i++)
                {
                    int txResult = device.Transmit(txFrame);
                    Console.WriteLine($"Transmit result: {txResult}");
                    System.Threading.Thread.Sleep(1000);
                }

                // Read frames
                for (int i = 0; i < 10; i++)
                {
                    var rxFrame = new Slcanv1Frame();
                    int rxResult = device.ReadMessage(out rxFrame);

                    if (rxResult == 0)
                    {
                        Console.Write($"Received frame ID: {rxFrame.id}, Data: ");
                        foreach (var b in rxFrame.data)
                            Console.Write($"{b} ");
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine("No frame received");
                    }
                }

                // Close device
                device.Close();
                Console.WriteLine("Device closed");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}
