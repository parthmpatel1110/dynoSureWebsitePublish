import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import os
import pandas as pd
import can.io.asc
import cantools
import datetime


def get_base_datetime_from_asc(asc_file):
    """
    Reads the ASC file header to extract the absolute start date/time.
    Returns a datetime object.
    """
    import datetime

    with open(asc_file, "r", errors="ignore") as f:
        for line in f:
            if line.lower().startswith("date "):
                # Example: "date Sat Aug 16 3:9:53 pm 2025"
                parts = line.strip().split(" ", 1)[1]

                # Normalize spacing and lowercase AM/PM
                parts = parts.replace("am", "AM").replace("pm", "PM")

                try:
                    # Try parsing with this flexible format
                    base_time = datetime.datetime.strptime(parts, "%a %b %d %I:%M:%S %p %Y")
                except ValueError:
                    # If single-digit minutes/seconds were not padded, Python still handles it.
                    # But if milliseconds exist, add another fallback
                    try:
                        base_time = datetime.datetime.strptime(parts, "%a %b %d %I:%M:%S.%f %p %Y")
                    except ValueError as e:
                        raise ValueError(f"Could not parse ASC date line: {parts}") from e

                return base_time

    raise ValueError("No date header found in ASC file")

def convert_asc_to_excel(dbc_file, asc_file, raster, output_file):
    """
    Decodes CAN messages from an ASC file using a DBC database and
    exports the decoded signals with absolute datetime.
    """
    try:
        # Load the DBC file
        db = cantools.database.load_file(dbc_file)

        # Extract the start datetime from header
        base_datetime = get_base_datetime_from_asc(asc_file)

        # Use python-can's AscReader
        reader = can.io.asc.ASCReader(asc_file)

        data_rows = []

        for msg in reader:
            try:
                decoded_msg = db.decode_message(msg.arbitration_id, msg.data)

                # Convert timestamp (relative sec) to absolute datetime
                abs_time = base_datetime + datetime.timedelta(seconds=msg.timestamp)

                row_data = {'timestamp': msg.timestamp,
                            'datetime': abs_time}
                row_data.update(decoded_msg)

                data_rows.append(row_data)

            except Exception as e:
                print(f"Could not decode message ID {msg.arbitration_id}: {e}")

        if not data_rows:
            messagebox.showinfo("No Data", "No messages found in the log file.")
            return False

        df = pd.DataFrame(data_rows)

        # Set datetime as index for resampling
        df = df.set_index("datetime")

        # Save to CSV (Excel also possible with .to_excel)
        df.to_csv(output_file, index=True)

        return True

    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")
        return False


class ConverterApp(tk.Tk):
    """
    A simple GUI application to convert ASC log files to Excel.
    """
    def __init__(self):
        super().__init__()
        self.title("ASC to Excel Converter")
        self.geometry("600x300")
        self.configure(bg="#f0f0f0")

        # Set up styles for widgets
        self.style = ttk.Style(self)
        self.style.theme_use('clam')
        self.style.configure('TFrame', background='#f0f0f0')
        self.style.configure('TButton', font=('Arial', 10, 'bold'), padding=5, background='#e1e1e1')
        self.style.map('TButton', background=[('active', '#d1d1d1')])
        self.style.configure('TLabel', background='#f0f0f0', font=('Arial', 10))
        self.style.configure('Header.TLabel', font=('Arial', 14, 'bold'), foreground='#333333')

        self.dbc_path = tk.StringVar()
        self.asc_path = tk.StringVar()
        self.time_interval = tk.StringVar(value="0.1") # Default time interval

        self.create_widgets()

    def create_widgets(self):
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(pady=10)
        ttk.Label(header_frame, text="ASC to Excel Converter", style='Header.TLabel').pack()

        # Main frame for content
        main_frame = ttk.Frame(self)
        main_frame.pack(padx=20, pady=10, fill="both", expand=True)

        # DBC file selection
        dbc_frame = ttk.Frame(main_frame)
        dbc_frame.pack(fill="x", pady=5)
        ttk.Label(dbc_frame, text="DBC File:").pack(side="left", padx=(0, 5))
        ttk.Entry(dbc_frame, textvariable=self.dbc_path, state="readonly").pack(side="left", fill="x", expand=True)
        ttk.Button(dbc_frame, text="Browse", command=self.select_dbc_file).pack(side="right", padx=(5, 0))

        # ASC file selection
        asc_frame = ttk.Frame(main_frame)
        asc_frame.pack(fill="x", pady=5)
        ttk.Label(asc_frame, text="ASC File:").pack(side="left", padx=(0, 5))
        ttk.Entry(asc_frame, textvariable=self.asc_path, state="readonly").pack(side="left", fill="x", expand=True)
        ttk.Button(asc_frame, text="Browse", command=self.select_asc_file).pack(side="right", padx=(5, 0))

        # Convert button
        ttk.Button(main_frame, text="Convert and Save to Excel", command=self.on_convert_button_click).pack(pady=20, ipadx=10, ipady=5)

        # Status Label
        self.status_label = ttk.Label(self, text="", foreground="green")
        self.status_label.pack(pady=10)

    def select_dbc_file(self):
        filename = filedialog.askopenfilename(
            title="Select DBC File",
            filetypes=(("DBC files", "*.dbc"), ("All files", "*.*"))
        )
        if filename:
            self.dbc_path.set(filename)

    def select_asc_file(self):
        filename = filedialog.askopenfilename(
            title="Select ASC File",
            filetypes=(("ASC files", "*.asc"), ("All files", "*.*"))
        )
        if filename:
            self.asc_path.set(filename)

    def on_convert_button_click(self):
        dbc_file = self.dbc_path.get()
        asc_file = self.asc_path.get()
        raster_str = self.time_interval.get()

        if not dbc_file or not asc_file:
            messagebox.showerror("Input Error", "Please select both a DBC and an ASC file.")
            return
        
        try:
            raster = float(raster_str)
            if raster <= 0:
                messagebox.showerror("Input Error", "Time interval must be a positive number.")
                return
        except ValueError:
            messagebox.showerror("Input Error", "Invalid time interval format. Please enter a number.")
            return
        
        output_file = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=(("csv files", "*.csv"), ("All files", "*.*")),
            title="Save Decoded Data as Excel File"
        )

        if not output_file:
            return # User cancelled save dialog

        self.status_label.config(text="Processing...", foreground="blue")
        self.update_idletasks() # Force GUI update

        if convert_asc_to_excel(dbc_file, asc_file, 1, output_file):
            self.status_label.config(text=f"Conversion successful! Data saved to {os.path.basename(output_file)}", foreground="green")
        else:
            self.status_label.config(text="Conversion failed.", foreground="red")


if __name__ == "__main__":
    app = ConverterApp()
    app.mainloop()
