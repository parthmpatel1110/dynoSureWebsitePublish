First time
1. install python.
2. open cmd in the folder
3. run python -m pip install -r .\requirements.txt
4. run python v1.py

then onwards, 
Right click on v1.py and open with python