import can
from slcanv1 import SlcanV1


def main():

    slcan = SlcanV1()
    print("Channel:", slcan.get_channel())

    # Adjust these parameters to your setup
    port = slcan.get_channel()    # Windows (e.g., 'COM3'), or '/dev/ttyUSB0' on Linux
    port = port[7:-1]
    print(port)
    bitrate = 500000

    # Create a bus instance with the new interface argument
    bus = can.Bus(
        interface='slcan',
        channel=port,
        bitrate=bitrate
    )

    print(f"Listening on {port} at {bitrate} bps...")

    try:
        while True:
            message = bus.recv(timeout=1.0)  # Wait up to 1 second for a message
            if message:
                print(f"ID: {message.arbitration_id:X} "
                      f"Data: {message.data.hex()} "
                      f"DLC: {message.dlc}")
    except KeyboardInterrupt:
        print("Stopped by user")

if __name__ == "__main__":
    main()
