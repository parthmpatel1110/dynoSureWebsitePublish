import can
import time
from slcanv1 import SlcanV1


def main():
    # Adjust to your setup

    slcan = SlcanV1()
    print("Channel:", slcan.get_channel())

    # Adjust these parameters to your setup
    port = slcan.get_channel()    # Windows (e.g., 'COM3'), or '/dev/ttyUSB0' on Linux
    port = port[7:-1]
    bitrate = 500000

    # Open SLCAN interface
    bus = can.Bus(
        interface="slcan",
        channel=port,
        bitrate=bitrate
    )

    print(f"Connected to {port} at {bitrate} bps")
    i = 0
    try:
        # Example: Transmit a CAN frame every 2 seconds
        while 1:
            msg = can.Message(
                arbitration_id=0x123,     # CAN ID
                data=[i, 2, 3, 4, 5, 6, 7, 8],  # Payload (up to 8 bytes for classic CAN)
                is_extended_id=False
            )
            try:
                bus.send(msg)
                print(f"TX -> ID: {msg.arbitration_id:X}, Data: {msg.data.hex()}")
            except can.CanError:
                print("TX Failed")
            i = i + 1
            time.sleep(2)        

    except KeyboardInterrupt:
        print("\nStopped by user")

if __name__ == "__main__":
    main()
