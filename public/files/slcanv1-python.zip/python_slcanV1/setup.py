from setuptools import setup, find_packages

setup(
    name='slcanv1',
    version='0.3.6',
    packages=find_packages(),
    include_package_data=True,
    package_data={'slcanv1': ['*.dll']},
    author='Parth Patel',
    author_email='dynosure.india@gmail.com',
    description='Python wrapper for slcanv1.dll',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    zip_safe=False,
)
