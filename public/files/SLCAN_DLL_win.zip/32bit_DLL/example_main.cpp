#include <stdio.h>
#include <windows.h>
#include "slcanv2.h"


// Precise microsecond delay using Windows API
void DelayMicroseconds(long long us) {
    LARGE_INTEGER freq;
    LARGE_INTEGER start, current;
    
    // Get high-resolution timer frequency
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&start);
    
    // Calculate total ticks to wait
    long long waitTicks = (freq.QuadPart * us) / 1000000LL;
    
    do {
        QueryPerformanceCounter(&current);
    } while (current.QuadPart - start.QuadPart < waitTicks);
}

// Callback function for received CAN packets
void __cdecl my_rx_callback(slcanv2PacketFD* f) {
    // printf("[CALLBACK] RX: ID=0x%03X [%d]%s ", 
    //        f->id, f->dlc, f->fd ? " FD" : "");
    
    // int len = f->dlc;
    // if (len > 64) len = 64;
    
    // for (int i = 0; i < len; i++) {
    //     printf("%02X ", f->data[i]);
    // }
    // printf(" (TS: %s)", f->timestamp_formated);
    
    // printf("\n");
    static int j = 0;
    
    if(f->error == 1)
    {
        j ++;
        printf("i = %d \t",j);
        // printf("[POLLING] ID=0x%03X [%d] ", f->id, f->dlc);
        // for (int i = 0; i < f->dlc; i++) printf("%02X ", f->data[i]);
        // printf(" (TS: %s)", f->timestamp_formated);
        // printf(" (TS: %lld)", f->timestamp);
        // printf(" (MSG: %lld)", f->msg_type);
        // printf("\n");
        printf("[POLLING] Bus Error: %s (Status: %d, Level: %d)\n", f->error_msg, f->bus_status, f->error_level);
        printf("\n");
    }
    if(f->msg_type == 2)
    {
        
        printf("i = %d \t",j);
        // printf("[POLLING] ID=0x%03X [%d] ", f->id, f->dlc);
        for (int i = 0; i < f->dlc; i++) printf("%02X ", f->data[i]);
        // printf(" (TS: %s)", f->timestamp_formated);
        // printf(" (TS: %lld)", f->timestamp);
        // printf(" (MSG: %lld)", f->msg_type);
        // printf("\n");
        // printf("[POLLING] Bus Error: %s (Status: %d, Level: %d)\n", f->error_msg, f->bus_status, f->error_level);
        printf("\n");
    }
}

int main() {
    printf("SLCANV2 Example Application\n");
    printf("===========================\n\n");

    // 1. Enumerate devices
    slcanv2DeviceInfo devices[10];
    int32_t count = slcanv2_enum_devices(devices, 10);
    if (count <= 0) {
        printf("No SLCANV2/Candlelight devices found.\n");
        return 1;
    }

    printf("Found %d device(s):\n", count);
    for (int i = 0; i < count; i++) {
        printf("%d.) %s (Serial: %s)\n", i + 1, devices[i].displayName, devices[i].serialNo);
    }

    // 2. Open the first device
    printf("\nOpening device 1...\n");
    slcanv2hnd hnd = slcanv2_open(devices[0].devicePath);
    if (!hnd) {
        printf("Error: Could not open device.\n");
        return 1;
    }

    // 3. Configure Bitrate
    slcanv2_set_bitrate_advanced(hnd, 0, 2, 119, 40);

    // ---------------------------------------------------------
    // PART 1: Demonstrate RX Callback
    // ---------------------------------------------------------
    printf("\n--- Part 1: Background RX Callback ---\n");
    // slcanv2_set_rx_callback(hnd, my_rx_callback);e

    // Using LOOPBACK mode so we can receive our own test packet
    // without needing an external CAN node to ACK the frame.
    printf("Starting CAN interface (LOOPBACK mode)...\n");
    // slcanv2_add_mask_filter(hnd, 0, 0x781, 0x7FF);
    slcanv2_start_with_flags(hnd, SLCANV2_FLAG_NORMAL | SLCANV2_FLAG_DISABLE_TX_ECHO  );
    Sleep(1000);
    slcanv2PacketFD tx = {0};
    tx.id = 0x78;
    tx.dlc = 4;
    tx.data[0] = 0xC0; tx.data[1] = 0xFF; tx.data[2] = 0xEE; tx.data[3] = 0x00;
    
    // if (slcanv2_send_packet(hnd, &tx) == 0) {
    //     printf("Sent test packet: ID=0x111. Wait for callback...\n");
    // }
    // Sleep(10000); // Give the background thread time to print

    // Stop the callback thread before demonstrating polling
    // slcanv2_set_rx_callback(hnd, NULL);
    printf("Stopped background RX callback.\n");
    // ---------------------------------------------------------
    // PART 2: Demonstrate Synchronous Polling
    // ---------------------------------------------------------
    printf("\n--- Part 2: Synchronous Polling ---\n");
    
    tx.id = 0x781;
    tx.dlc = 8;
    tx.data[0] = 0x00; 
    tx.data[1] = 0x00; 
    tx.data[2] = 0x00; 
    tx.data[3] = 0x00;
    
    // if (slcanv2_send_packet(hnd, &tx) == 0) {
    //     printf("Sent test packet: ID=0x222. Polling for response...\n");
    // }
    
    Sleep(1000);
    slcanv2PacketFD rx = {0};
    int j = 0;
    int32_t res = 0; // 1000ms timeout

    
    j = 0;
    int startTick = GetTickCount();
    // for(int i = 0 ; i < 1000;i++ )
    // {   
    //     res = slcanv2_send_packet(hnd, &tx,10000);
    //     if(res != 0)
    //         printf("send error timeout. %d \n",res);
    //     // while(res == ERROR_CODE_IN_FEEDBACK)
    //     //     res = slcanv2_send_packet(hnd, &tx);
    //     //     printf("ERROR_CODE_IN_FEEDBACK");
    //     //     printf("\n");
    //     tx.data[0]++;
    //     if(tx.data[0] == 0xFF)
    //     {
    //         tx.data[0] = 0xFE;
    //         tx.data[1]++;
    //         if(tx.data[1] == 0xFF)
    //         {
    //             tx.data[1] = 0xFE;
    //             tx.data[2]++;
    //             if(tx.data[2] == 0xFF)
    //             {
    //                 tx.data[2] = 0xFE;
    //                 tx.data[3]++;
    //             }
    //         }
    //     }
    //     // DelayMicroseconds(200);
    //     // Sleep(1);
    //     // int32_t res = slcanv2_receive_packet(hnd, &rx, 0); // 1000ms timeout
    //     // if (res == 1) {
    //     //     printf("i = %d",j);
    //     //     printf("[POLLING] ID=0x%03X [%d] ", rx.id, rx.dlc);
    //     //     for (int i = 0; i < rx.dlc; i++) printf("%02X ", rx.data[i]);
    //     //     printf(" (TS: %s)", rx.timestamp_formated);
    //     //     printf(" (TS: %lld)", rx.timestamp);
    //     //     printf(" (MSG: %lld)", rx.msg_type);
    //     //     printf("\n");
    //     //     j++;
    //     // } else if (res == ERROR_TIMEOUT) {
    //     //     printf("[POLLING] Timeout waiting for packet.\n");
    //     // } else if (res == -2) {
    //     //     printf("[POLLING] Bus Error: %s (Status: %d, Level: %d)\n", rx.error_msg, rx.bus_status, rx.error_level);
    //     // } else {
    //     //     printf("[POLLING] Error receiving packet (code: %d).\n", res);
    //     // }
    // }
    

    while( j < 3000 )
    {
        
        int32_t res = slcanv2_receive_packet(hnd, &rx, 1000); // 1000ms timeout
        if (res == 1) {
            printf("i = %d",j);
            printf("[POLLING] ID=0x%03X [%d] ", rx.id, rx.dlc);
            for (int i = 0; i < rx.dlc; i++) printf("%02X ", rx.data[i]);
            printf(" (TS: %s)", rx.timestamp_formated);
            printf(" (TS: %lld)", rx.timestamp);
            printf("\n");
            // j++;
        } else if (res == 0) {
            printf("[POLLING] Timeout waiting for packet.\n");
        } else if (res == -2) {
            printf("[POLLING] Bus Error: %s (Status: %d, Level: %d)\n", rx.error_msg, rx.bus_status, rx.error_level);
        } else {
            printf("[POLLING] Error receiving packet (code: %d).\n", res);
        }
        // Sleep(1);
    }
    // Clean up
    Sleep(5000);
    printf("\nClosing device...\n");
    slcanv2_close(hnd);
    printf("Finished.\n");

    return 0;
}
