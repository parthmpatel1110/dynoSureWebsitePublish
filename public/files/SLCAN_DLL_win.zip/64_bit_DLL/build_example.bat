@echo off
setlocal
for /f "usebackq tokens=*" %%i in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do (
  set "VS_PATH=%%i"
)
call "%VS_PATH%\VC\Auxiliary\Build\vcvarsall.bat" x64

echo Compiling example_main.cpp...
cl.exe /EHsc /MD /O2 example_main.cpp slcanv2.lib /link /out:example.exe

if %ERRORLEVEL% EQU 0 (
    echo.
    echo Successfully built example.exe
    echo Make sure slcanv2.dll is in the same directory when running.
) else (
    echo.
    echo Failed to build example.exe
)
